﻿# Training & E-Learning Module (ISO 9001 / LMS)

โมดูลระบบฝึกอบรมและ E-Learning สำหรับ Next.js 15+ (App Router)

## โครงสร้างไฟล์ทั้งหมด (File Structure):
1. UI Components:
   - components/training/LessonVideoPlayer.tsx      : เครื่องเล่นวิดีโอ จุดคั่นคำถาม (240p-720p) ป้องกันการกอข้าม
   - components/training/ElearningView.tsx          : หน้าห้องเรียนออนไลน์ สรุปผลสอบ และใบรับรอง E-Certificate
   - components/training/ElearningEditorModal.tsx   : Modal จัดการและแก้ไขเนื้อหาบทเรียน
   - components/training/videoUtils.ts              : ตัวช่วยแปลงลิงก์ YouTube และ Local Video
   - components/training/TrainingCourseListView.tsx : หน้ารายการหลักสูตรอบรม
   - components/training/TrainingCourseModal.tsx    : Modal เพิ่ม/แก้ไขหลักสูตรอบรม
   - components/training/TrainingListView.tsx       : หน้ารายการทะเบียนประวัติการอบรม
   - components/training/TrainingFormModal.tsx      : Modal บันทึกประวัติการอบรม

2. Pages & API Routes:
   - app/(main)/elearning/page.tsx                  : Route หน้า /elearning
   - app/(main)/training/page.tsx                   : Route หน้า /training
   - app/(main)/training-courses/page.tsx           : Route หน้า /training-courses
   - app/api/upload-video/route.ts                  : API รับอัปโหลดไฟล์วิดีโอ
   - app/api/videos/[filename]/route.ts             : API สตรีมวิดีโอรองรับ HTTP 206 Partial Content

3. Backend Actions & Logic:
   - lib/training/elearningActions.ts               : ฟังก์ชันส่งผลสอบและออกใบรับรอง
   - lib/training/courseActions.ts & courseQueries.ts: การบันทึก/ดึงข้อมูลหลักสูตร
   - lib/training/queries.ts & actions.ts           : การบันทึก/ดึงประวัติการอบรมพนักงาน

4. Data Seeds:
   - data/elearningCurriculum.ts                    : เนื้อหาบทเรียน ISO 4 Chapters, Checkpoints คำถาม, และข้อสอบ
   - data/trainingCourses.ts                        : รายชื่อหลักสูตรอบรม (CRS-01, CRS-02, CRS-03)
   - data/training.ts                               : ประวัติการฝึกอบรมเริ่มต้น
